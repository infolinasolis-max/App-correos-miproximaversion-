# Test «¿Qué te está frenando?» · Mi Próxima Versión

Mini app que, al terminar el test, **guarda a la persona en Brevo y le envía su resultado por correo**. Incluye un panel privado (`/admin`) para ver suscriptoras y enviar correos.

## Qué hay en la carpeta
- `index.html` → el test (lo que ve la gente)
- `admin/index.html` → tu panel privado (`tusitio.com/admin`)
- `api/` → funciones del servidor (hablan con Brevo; la clave nunca queda en la página)
- `api/_lib/content.js` → **todos los textos del test** (preguntas, frenos, ejercicios). Si cambias algo, cámbialo aquí y se actualiza en la web y en el correo.

## Paso 1 · Brevo (gratis)
1. Crea tu cuenta en brevo.com.
2. **Remitente verificado**: Configuración → Remitentes, dominios e IP → agrega el correo desde el que enviarás y confírmalo. Lo ideal es un correo con tu propio dominio (hola@tudominio.com); con Gmail muchos correos caerán en spam.
3. **Clave API**: Configuración → SMTP y API → Claves API → *Generar una nueva clave*. Cópiala.
4. El plan gratis permite unos 300 correos al día.

## Paso 2 · Subir a GitHub y Vercel
1. Sube **esta carpeta** a un repositorio de GitHub (sin la carpeta `dev` si existe).
2. En Vercel: *Add New → Project* → elige el repositorio → *Deploy*.

## Paso 3 · Variables en Vercel
Project → Settings → Environment Variables:

| Variable | Qué poner | Obligatoria |
|---|---|---|
| `BREVO_API_KEY` | tu clave API de Brevo | Sí |
| `BREVO_SENDER_EMAIL` | el remitente verificado | Sí |
| `ADMIN_PASSWORD` | la contraseña de tu panel (larga) | Sí |
| `BREVO_SENDER_NAME` | nombre que ven al recibir (por defecto «Mi Próxima Versión») | No |
| `CTA_URL` | enlace a tu producto; muestra un botón al final del resultado y del correo | No |
| `CTA_TEXT` | frase que acompaña ese botón | No |
| `BREVO_LIST_ID` | ID de una lista de Brevo; si lo dejas vacío se crea sola «Mi Próxima Versión · Test de frenos» | No |

Después de guardar las variables: Deployments → ⋯ → **Redeploy**.

## Paso 4 · Probar
1. Haz el test con tu propio correo: debes ver el resultado y recibir el correo (mira también Promociones/Spam).
2. Entra a `/admin` con tu contraseña: verás tu registro.
3. En el panel, escribe un correo y usa **Enviar prueba** antes de enviarlo a todas.

## Usar el panel
- Estadísticas por freno, buscador, filtro y **descarga CSV**.
- **Enviar un correo** a todas o solo a las de un freno. `{nombre}` se reemplaza por el nombre de cada persona. Cada correo lleva el enlace de cancelar suscripción (obligatorio y automático).
- Quien se da de baja aparece como «Baja» y ya no recibe envíos.

## Si algo falla
- «Falta configurar…» → falta una variable en Vercel (y redeploy).
- El resultado se ve pero no llega el correo → remitente sin verificar en Brevo, o clave API incorrecta (mira Vercel → Logs).
- Más de ~300 envíos al día → límite del plan gratis de Brevo.
