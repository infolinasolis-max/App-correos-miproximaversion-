const { FRENOS, validAnswers, compute } = require("./_lib/content");
const brevo = require("./_lib/brevo");
const { resultEmail } = require("./_lib/email");

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const hits = new Map(); // límite sencillo por IP (en memoria, por instancia)

function tooMany(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > 6;
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Método no permitido" });
  const body = typeof req.body === "string" ? safeJson(req.body) : req.body || {};

  if (body.web) return res.status(200).json({ ok: true }); // trampa para bots: respondemos "ok" sin hacer nada

  const ip = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "local";
  if (tooMany(ip)) return res.status(429).json({ ok: false, error: "Demasiados intentos. Espera un minuto e inténtalo de nuevo." });

  const email = String(body.email || "").trim().toLowerCase();
  const name = String(body.name || "").trim().replace(/[<>]/g, "").slice(0, 60);
  if (!EMAIL_RE.test(email) || email.length > 160) return res.status(400).json({ ok: false, error: "Escribe un correo válido para enviarte tu resultado." });
  if (!validAnswers(body.answers)) return res.status(400).json({ ok: false, error: "No pudimos leer tus respuestas. Repite el test." });

  const result = compute(body.answers);
  const main = FRENOS[result.main];

  // 1) guardar/actualizar el contacto en Brevo
  try {
    const listId = await brevo.getListId();
    await brevo.upsertContact({ email, name, freno: main.name, listId });
  } catch (e) {
    console.error("[subscribe] contacto", e.message);
    return res.status(502).json({ ok: false, error: "No pudimos guardar tu correo en este momento. Inténtalo de nuevo en unos minutos." });
  }

  // 2) enviar el resultado por correo (si falla, igualmente mostramos el resultado en pantalla)
  let emailSent = false;
  try {
    const mail = resultEmail({ name, result, ctaUrl: process.env.CTA_URL, ctaText: process.env.CTA_TEXT });
    await brevo.sendEmail({ to: email, toName: name, subject: mail.subject, html: mail.html, tags: ["test-frenos", "resultado"] });
    emailSent = true;
  } catch (e) {
    console.error("[subscribe] email", e.message);
  }

  res.status(200).json({ ok: true, emailSent, result });
};

function safeJson(s) { try { return JSON.parse(s); } catch (_) { return {}; } }
