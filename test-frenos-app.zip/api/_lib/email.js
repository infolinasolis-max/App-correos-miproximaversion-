// Plantillas de correo (HTML compatible con Gmail/Outlook/Apple Mail: tablas y estilos en línea).
const { FRENOS } = require("./content");

const C = { pink: "#F4D3DA", pinkL: "#FAE6EA", beige: "#F8F1E7", gold: "#BF9A44", goldD: "#9A762B", goldL: "#E3CF9F", brown: "#5B4439", soft: "#8C7468" };
const SERIF = "Georgia,'Times New Roman',serif";
const SANS = "'Helvetica Neue',Helvetica,Arial,sans-serif";
const IG = "https://www.instagram.com/miproximaversion/";

const esc = (s) => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function shell({ preheader, inner, footer }) {
  return `<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>Mi Próxima Versión</title></head>
<body style="margin:0;padding:0;background:${C.pink};">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:${C.pink};">${esc(preheader || "")}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${C.pink}" style="background:${C.pink};"><tr><td align="center" style="padding:24px 12px;">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" bgcolor="${C.beige}" style="width:100%;max-width:600px;background:${C.beige};border:1px solid ${C.gold};border-radius:18px;">
<tr><td align="center" style="padding:30px 32px 0;font-family:${SANS};font-size:11px;letter-spacing:4px;text-transform:uppercase;color:${C.goldD};">Mi Próxima Versión</td></tr>
<tr><td align="center" style="padding:10px 32px 0;color:${C.gold};font-size:14px;line-height:14px;">&#9670;</td></tr>
${inner}
<tr><td style="padding:26px 32px 30px;border-top:1px solid ${C.goldL};font-family:${SANS};font-size:12px;line-height:1.6;color:${C.soft};text-align:center;">
${footer}
</td></tr>
</table>
</td></tr></table>
</body></html>`;
}

function button(text, url) {
  return `<table role="presentation" cellpadding="0" cellspacing="0" border="0" align="center" style="margin:6px auto;"><tr><td align="center" bgcolor="${C.goldD}" style="border-radius:30px;">
<a href="${esc(url)}" style="display:inline-block;padding:15px 34px;font-family:${SANS};font-size:13px;font-weight:bold;letter-spacing:2px;text-transform:uppercase;color:#ffffff;text-decoration:none;">${esc(text)}</a></td></tr></table>`;
}

function p(text, extra) {
  return `<p style="margin:0 0 14px;font-family:${SANS};font-size:15px;line-height:1.7;color:${C.brown};${extra || ""}">${text}</p>`;
}

/* ---------- correo con el resultado del test ---------- */
function resultEmail({ name, result, ctaUrl, ctaText }) {
  const main = FRENOS[result.main];
  const low = FRENOS[result.order[4]];
  const second = result.scores[result.order[1]] >= 3 ? FRENOS[result.order[1]] : null;
  const soft = result.scores[result.main] <= 2;
  const hi = name ? `Hola, ${esc(name)}` : "Hola";

  const bars = result.order.map((i, pos) => {
    const pc = Math.max(result.pct[i], 4);
    const lvl = result.pct[i] < 34 ? "Bajo" : result.pct[i] < 67 ? "Medio" : "Alto";
    const colr = pos === 0 ? C.goldD : C.gold;
    return `<tr><td style="padding:10px 0 4px;font-family:${SANS};font-size:13px;color:${pos === 0 ? C.goldD : C.brown};font-weight:${pos === 0 ? "bold" : "normal"};">${esc(FRENOS[i].name)}</td>
<td align="right" style="padding:10px 0 4px;font-family:${SANS};font-size:12px;color:${C.soft};">${lvl} · ${result.pct[i]}%</td></tr>
<tr><td colspan="2"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
<td width="${pc}%" height="8" bgcolor="${colr}" style="height:8px;line-height:8px;font-size:0;border-radius:6px;">&nbsp;</td>
<td width="${100 - pc}%" height="8" bgcolor="${C.pink}" style="height:8px;line-height:8px;font-size:0;">&nbsp;</td></tr></table></td></tr>`;
  }).join("");

  const pasa = main.pasa.map((t) => `<tr><td valign="top" width="18" style="padding:4px 0;color:${C.gold};font-size:10px;font-family:${SANS};">&#9670;</td><td style="padding:3px 0;font-family:${SANS};font-size:14px;line-height:1.55;color:${C.brown};">${esc(t)}</td></tr>`).join("");

  const inner = `
<tr><td align="center" style="padding:14px 32px 0;font-family:${SANS};font-size:12px;letter-spacing:3px;text-transform:uppercase;color:${C.goldD};">Tu freno principal</td></tr>
<tr><td align="center" style="padding:6px 32px 0;font-family:${SERIF};font-size:76px;line-height:80px;color:${C.gold};">${main.n}</td></tr>
<tr><td align="center" style="padding:0 32px;font-family:${SERIF};font-size:30px;line-height:1.2;color:${C.brown};">${esc(main.name)}</td></tr>
${second ? `<tr><td align="center" style="padding:8px 32px 0;font-family:${SANS};font-size:12px;color:${C.soft};">Después pesa: <strong style="color:${C.goldD};">${esc(second.name)}</strong></td></tr>` : ""}
<tr><td style="padding:24px 32px 6px;">
${p(hi + ",")}
${p(`${soft ? "Tus frenos son suaves, y eso es una gran noticia. Aun así, este es el que más pesa hoy. " : ""}${esc(main.desc)}`)}
</td></tr>
<tr><td style="padding:6px 32px 0;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${C.pinkL}" style="background:${C.pinkL};border:1px solid ${C.goldL};border-radius:14px;"><tr><td style="padding:18px 20px;">
<div style="font-family:${SANS};font-size:10px;font-weight:bold;letter-spacing:3px;text-transform:uppercase;color:${C.goldD};padding-bottom:8px;">Lo que suele pasar</div>
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">${pasa}</table>
</td></tr></table></td></tr>
<tr><td style="padding:26px 32px 0;"><div style="font-family:${SERIF};font-size:21px;color:${C.brown};padding-bottom:4px;">Tu mapa de frenos</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">${bars}</table></td></tr>
<tr><td style="padding:24px 32px 0;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${C.pinkL}" style="background:${C.pinkL};border:1px solid ${C.goldL};border-radius:14px;"><tr><td style="padding:16px 20px;">
<div style="font-family:${SANS};font-size:10px;font-weight:bold;letter-spacing:3px;text-transform:uppercase;color:${C.goldD};padding-bottom:6px;">Tu punto a favor</div>
<div style="font-family:${SANS};font-size:14px;line-height:1.6;color:${C.brown};">${esc(low.fuerte)}</div></td></tr></table></td></tr>
<tr><td style="padding:24px 32px 0;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="${C.pink}" style="background:${C.pink};border:1px solid ${C.gold};border-radius:14px;"><tr><td style="padding:20px 22px;">
<div style="font-family:${SANS};font-size:10px;font-weight:bold;letter-spacing:3px;text-transform:uppercase;color:${C.goldD};">Tu primer ejercicio</div>
<div style="font-family:${SERIF};font-size:22px;line-height:1.25;color:${C.brown};padding:6px 0 8px;">${esc(main.ex.t)}</div>
<div style="font-family:${SANS};font-size:14px;line-height:1.65;color:${C.brown};">${esc(main.ex.x)}</div></td></tr></table></td></tr>
<tr><td align="center" style="padding:26px 40px 0;border-top:0;"><div style="border-top:1px solid ${C.gold};border-bottom:1px solid ${C.gold};padding:18px 6px;">
<div style="font-family:${SANS};font-size:10px;font-weight:bold;letter-spacing:3px;text-transform:uppercase;color:${C.goldD};padding-bottom:8px;">Pregunta para llevarte</div>
<div style="font-family:${SERIF};font-style:italic;font-size:19px;line-height:1.45;color:${C.goldD};">«${esc(main.q)}»</div></div></td></tr>
${ctaUrl ? `<tr><td style="padding:26px 32px 0;" align="center">${p(esc(ctaText || ""), "text-align:center;")}${button("Quiero seguir", ctaUrl)}</td></tr>` : ""}
<tr><td align="center" style="padding:24px 32px 26px;font-family:${SANS};font-size:14px;color:${C.brown};">Con cariño,<br><span style="font-family:${SERIF};font-size:18px;">Mi Próxima Versión</span></td></tr>`;

  const footer = `Recibiste este correo porque completaste el test «¿Qué te está frenando?». Si no fuiste tú, puedes ignorarlo.<br>
Sígueme en <a href="${IG}" style="color:${C.goldD};">@miproximaversion</a>. Si no quieres recibir más novedades, usa el enlace de cancelar suscripción que incluye cada boletín.`;

  return {
    subject: `Tu resultado: ${main.name} · ¿Qué te está frenando?`,
    html: shell({ preheader: `Tu freno principal es «${main.name}». Aquí está tu mapa y tu primer ejercicio.`, inner, footer }),
  };
}

/* ---------- correos que redactas desde el panel ---------- */
function textToHtml(text, { test } = {}) {
  const nombre = test ? "amiga" : "{{ contact.FIRSTNAME | default: 'amiga' }}";
  return String(text || "").trim().split(/\n{2,}/).map((para) => {
    let h = esc(para).replace(/\n/g, "<br>");
    h = h.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    h = h.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, `<a href="$2" style="color:${C.goldD};">$1</a>`);
    h = h.replace(/(^|[^"'(>=])(https?:\/\/[^\s<)]+)/g, `$1<a href="$2" style="color:${C.goldD};">$2</a>`);
    h = h.replace(/\{nombre\}/gi, nombre);
    return p(h);
  }).join("\n");
}

function campaignEmail({ body, btnText, btnUrl, test }) {
  const inner = `<tr><td style="padding:22px 36px 6px;">${textToHtml(body, { test })}
${btnText && btnUrl ? `<div style="padding:10px 0 6px;">${button(btnText, btnUrl)}</div>` : ""}</td></tr>
<tr><td align="center" style="padding:6px 32px 22px;font-family:${SANS};font-size:14px;color:${C.brown};">Con cariño,<br><span style="font-family:${SERIF};font-size:18px;">Mi Próxima Versión</span></td></tr>`;
  const unsub = test ? "#" : "{{ unsubscribe }}";
  const footer = `Recibes este correo porque te registraste en Mi Próxima Versión.<br>
<a href="${IG}" style="color:${C.goldD};">@miproximaversion</a> · <a href="${unsub}" style="color:${C.goldD};">Cancelar suscripción</a>`;
  return shell({ preheader: "", inner, footer });
}

module.exports = { resultEmail, campaignEmail, esc };
