// Sesión del panel admin: token firmado con HMAC (sin base de datos).
const crypto = require("crypto");

function secret() {
  return process.env.SESSION_SECRET ||
    crypto.createHash("sha256").update("mpv:" + (process.env.ADMIN_PASSWORD || "") + (process.env.BREVO_API_KEY || "")).digest("hex");
}
const b64 = (s) => Buffer.from(s).toString("base64url");
const sign = (p) => crypto.createHmac("sha256", secret()).update(p).digest("base64url");

function checkPassword(given) {
  const real = process.env.ADMIN_PASSWORD || "";
  if (!real) return false;
  const a = crypto.createHash("sha256").update(String(given || "")).digest();
  const b = crypto.createHash("sha256").update(real).digest();
  return crypto.timingSafeEqual(a, b);
}

function issueToken(hours = 12) {
  const payload = b64(JSON.stringify({ exp: Date.now() + hours * 3600 * 1000 }));
  return { token: payload + "." + sign(payload), expiresInHours: hours };
}

function verifyToken(token) {
  if (!token || token.indexOf(".") < 0) return false;
  const [payload, sig] = token.split(".");
  const expected = sign(payload);
  try {
    if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
    const { exp } = JSON.parse(Buffer.from(payload, "base64url").toString());
    return typeof exp === "number" && exp > Date.now();
  } catch (_) { return false; }
}

// devuelve true si está autorizada; si no, responde 401 y devuelve false
function requireAuth(req, res) {
  const h = req.headers["authorization"] || "";
  const t = h.startsWith("Bearer ") ? h.slice(7) : "";
  if (!process.env.ADMIN_PASSWORD) { res.status(500).json({ ok: false, error: "Falta configurar ADMIN_PASSWORD en Vercel." }); return false; }
  if (!verifyToken(t)) { res.status(401).json({ ok: false, error: "Sesión caducada. Entra de nuevo." }); return false; }
  return true;
}

module.exports = { checkPassword, issueToken, verifyToken, requireAuth };
