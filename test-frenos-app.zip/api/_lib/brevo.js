// Cliente mínimo de la API v3 de Brevo (sin dependencias).
const BASE = process.env.BREVO_BASE_URL || "https://api.brevo.com/v3";
const LIST_NAME = "Mi Próxima Versión · Test de frenos";

async function api(method, path, body) {
  if (!process.env.BREVO_API_KEY) {
    const e = new Error("Falta la variable BREVO_API_KEY");
    e.status = 500;
    throw e;
  }
  const r = await fetch(BASE + path, {
    method,
    headers: { "api-key": process.env.BREVO_API_KEY, accept: "application/json", "content-type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await r.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (_) { data = { raw: text }; }
  if (!r.ok) {
    const e = new Error(`Brevo ${method} ${path} → ${r.status} ${(data && (data.message || data.raw)) || ""}`);
    e.status = r.status;
    e.data = data;
    throw e;
  }
  return data;
}

let attrsReady = null;
function ensureAttributes() {
  if (!attrsReady) {
    attrsReady = Promise.all(["FRENO", "TEST_FECHA"].map((n) =>
      api("POST", `/contacts/attributes/normal/${n}`, { type: "text" }).catch(() => null) // ya existe → se ignora
    )).catch(() => null);
  }
  return attrsReady;
}

let listIdCache = null;
async function getListId() {
  if (process.env.BREVO_LIST_ID) return Number(process.env.BREVO_LIST_ID);
  if (listIdCache) return listIdCache;
  let offset = 0;
  for (;;) {
    const d = await api("GET", `/contacts/lists?limit=50&offset=${offset}`);
    const found = (d.lists || []).find((l) => l.name === LIST_NAME);
    if (found) { listIdCache = found.id; return found.id; }
    if (!d.lists || d.lists.length < 50) break;
    offset += 50;
  }
  const f = await api("GET", "/contacts/folders?limit=50&offset=0");
  const folderId = f.folders && f.folders[0] && f.folders[0].id;
  const created = await api("POST", "/contacts/lists", { name: LIST_NAME, folderId });
  listIdCache = created.id;
  return created.id;
}

async function upsertContact({ email, name, freno, listId }) {
  await ensureAttributes();
  const attributes = { FRENO: freno, TEST_FECHA: new Date().toISOString().slice(0, 10) };
  if (name) attributes.FIRSTNAME = name;
  return api("POST", "/contacts", { email, attributes, listIds: [listId], updateEnabled: true });
}

function sender() {
  const email = process.env.BREVO_SENDER_EMAIL;
  if (!email) { const e = new Error("Falta la variable BREVO_SENDER_EMAIL"); e.status = 500; throw e; }
  return { name: process.env.BREVO_SENDER_NAME || "Mi Próxima Versión", email };
}

function sendEmail({ to, toName, subject, html, tags }) {
  const s = sender();
  return api("POST", "/smtp/email", {
    sender: s, replyTo: { email: s.email, name: s.name },
    to: [toName ? { email: to, name: toName } : { email: to }],
    subject, htmlContent: html, tags: tags || [],
  });
}

// Todos los contactos de la lista principal (hasta 5000)
async function listContacts(listId) {
  let all = [];
  for (let offset = 0; offset < 5000; offset += 500) {
    const d = await api("GET", `/contacts/lists/${listId}/contacts?limit=500&offset=${offset}&sort=desc`);
    const batch = d.contacts || [];
    all = all.concat(batch);
    if (batch.length < 500) break;
  }
  return all.map((c) => ({
    email: c.email,
    nombre: (c.attributes && c.attributes.FIRSTNAME) || "",
    freno: (c.attributes && c.attributes.FRENO) || "",
    fecha: (c.attributes && c.attributes.TEST_FECHA) || (c.createdAt || "").slice(0, 10),
    baja: !!c.emailBlacklisted,
  }));
}

module.exports = { api, ensureAttributes, getListId, upsertContact, sendEmail, sender, listContacts, LIST_NAME };
