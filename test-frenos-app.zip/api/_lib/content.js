// Contenido del test: UNA sola fuente para la web y para los correos.
// Para cambiar textos, edita este archivo.

const OPTIONS = ["No me describe", "Un poco", "Bastante", "Me describe totalmente"];

const FRENOS = [
  { id: "claridad", n: 1, name: "Falta de claridad",
    desc: "Haces mucho, pero sin una dirección clara. No es falta de ganas ni de capacidad: casi nadie nos enseña a decidir qué queremos de verdad, y sin ese norte, cualquier esfuerzo se dispersa. La buena noticia es que la claridad se construye, y se construye con preguntas, no con presión.",
    pasa: ["Empiezas cosas distintas y ninguna se consolida.", "Te sientes ocupada, pero sin un avance real.", "Postergas decisiones esperando «tener más claro»."],
    fuerte: "Tu diálogo interno y tu miedo no son tan fuertes como la dispersión: cuando por fin eliges una dirección, tienes energía para sostenerla.",
    ex: { t: "Tu brújula en 5 minutos", x: "Escribe sin editarte: ¿qué quiero sentir dentro de un año? Y completa: «Para que eso sea cierto, tendrían que pasar estas 3 cosas…». Después subraya la que más te emociona." },
    q: "Si no tuviera que justificarme ante nadie, ¿qué querría que fuera cierto de mi vida dentro de un año?" },
  { id: "creencias", n: 2, name: "Creencias limitantes",
    desc: "Hay ideas que das por ciertas sobre ti («no soy buena para esto», «ya es tarde», «no lo merezco») y que funcionan como un techo invisible. No son verdades: son conclusiones que sacaste con la información que tenías entonces, y pueden reescribirse.",
    pasa: ["Descartas oportunidades antes de intentarlas.", "Minimizas tus logros o los atribuyes a la suerte.", "Repites los mismos resultados en distintas áreas de tu vida."],
    fuerte: "Eres capaz de verte con honestidad: eso es justo lo que hace falta para cuestionar una creencia y cambiarla.",
    ex: { t: "Detective de creencias", x: "Escribe una creencia que te limita con tus palabras exactas. Luego busca UNA evidencia real que la contradiga (algo que hiciste y «no podías»). Termina con una versión más posible de esa frase." },
    q: "¿Qué creencia me ha protegido en el pasado, pero hoy ya no me sirve?" },
  { id: "miedo", n: 3, name: "Miedo al cambio",
    desc: "Tu mente intenta protegerte de lo desconocido: del fracaso, del juicio o de perder lo que ya tienes. El miedo no es el enemigo, pero cuando manda, te mantiene donde estás. No necesitas eliminarlo: necesitas aprender a avanzar con él.",
    pasa: ["Pospones el paso importante con buenas excusas.", "Imaginas el peor escenario como si fuera el más probable.", "Aparecen dudas justo cuando estás cerca de un cambio."],
    fuerte: "Tienes un gran instinto de cuidado: cuando conviertes tu miedo en información, decides con mucha más calma.",
    ex: { t: "Peor, mejor y más probable", x: "Elige un paso que estás evitando. Escribe el peor escenario realista (y cómo lo enfrentarías), el mejor y el más probable. Termina con el paso más pequeño que podrías dar esta semana." },
    q: "¿Qué le diría mi versión de dentro de cinco años a la mujer que soy hoy sobre este miedo?" },
  { id: "perfeccionismo", n: 4, name: "Perfeccionismo y comparación",
    desc: "Tu vara es tan alta que empezar se vuelve un riesgo, y la comparación te hace sentir siempre unos pasos atrás. El perfeccionismo parece exigencia, pero muchas veces es miedo disfrazado de buenos estándares.",
    pasa: ["Revisas y ajustas sin terminar ni mostrar nada.", "Te comparas con personas que van en otra etapa.", "Descartas lo que haces bien porque «podría estar mejor»."],
    fuerte: "Te importa la calidad y tienes buen criterio: cuando lo apuntas a terminar (y no a pulir sin fin), se vuelve tu superpoder.",
    ex: { t: "La versión «suficientemente buena»", x: "Elige una tarea que estás postergando y haz una versión suficientemente buena en 15 minutos. Termínala, no la mejores. Después anota qué pasó realmente (no lo que temías)." },
    q: "¿Qué haría hoy si supiera que lo imperfecto, pero terminado, vale más que lo perfecto que nunca llega?" },
  { id: "entorno", n: 5, name: "Entorno que sostiene lo de siempre",
    desc: "Lo que te rodea (personas, rutinas, espacios) sostiene a tu versión de siempre y se incomoda cuando cambias. No se trata de cortar con todo, sino de elegir con más conciencia dónde y con quién pones tu energía.",
    pasa: ["Sientes que nadie entiende lo que quieres lograr.", "Vuelves a viejas rutinas con ciertas personas o en ciertos lugares.", "Te cuesta sostener un cambio sola."],
    fuerte: "Tienes claro cuándo algo no te suma: esa sensibilidad te permite rediseñar tu entorno con decisiones pequeñas pero poderosas.",
    ex: { t: "Mapa de mi entorno", x: "Anota 3 personas o espacios que te impulsan y 1 que te devuelve al pasado. Elige un pequeño ajuste para esta semana (menos tiempo, un límite, una conversación) y escribe cómo lo harás." },
    q: "¿Qué personas, espacios o rutinas sostienen mi versión antigua, y qué ajuste pequeño puedo hacer esta semana?" },
];

// f = índice del freno al que suma la afirmación (dos por freno)
const QUESTIONS = [
  { f: 0, t: "Hago muchas cosas, pero siento que ninguna me acerca realmente a lo que quiero." },
  { f: 1, t: "Con frecuencia pienso «yo no soy de las que…» o «a mí estas cosas no me salen»." },
  { f: 2, t: "Dejo de intentar cosas que me importan por miedo a fallar o a que me juzguen." },
  { f: 3, t: "Si no puedo hacerlo perfecto, prefiero no empezar." },
  { f: 4, t: "Las personas cercanas no entienden o desaniman mis metas." },
  { f: 0, t: "Si me preguntan qué quiero lograr este año, me cuesta responder con claridad." },
  { f: 1, t: "En el fondo siento que no merezco todo lo que deseo." },
  { f: 2, t: "Me paralizo cuando estoy a punto de dar un paso importante o de cambiar algo." },
  { f: 3, t: "Me comparo con otras personas y siento que voy tarde o que no soy suficiente." },
  { f: 4, t: "Mis rutinas y mi entorno me llevan de vuelta a lo de siempre, aunque quiera cambiar." },
];

function validAnswers(a) {
  return Array.isArray(a) && a.length === QUESTIONS.length && a.every((v) => Number.isInteger(v) && v >= 0 && v <= 3);
}

function compute(answers) {
  const scores = FRENOS.map(() => 0);
  const first = FRENOS.map(() => 0);
  QUESTIONS.forEach((q, i) => { scores[q.f] += answers[i]; });
  QUESTIONS.slice(0, 5).forEach((q, i) => { first[q.f] = answers[i]; });
  const order = FRENOS.map((_, i) => i).sort((a, b) => (scores[b] - scores[a]) || (first[b] - first[a]) || (a - b));
  const pct = scores.map((s) => Math.round((s / 6) * 100));
  return { scores, pct, order, main: order[0] };
}

module.exports = { OPTIONS, FRENOS, QUESTIONS, validAnswers, compute };
