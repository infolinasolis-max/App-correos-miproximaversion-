const { requireAuth } = require("../_lib/auth");
const brevo = require("../_lib/brevo");
const { FRENOS } = require("../_lib/content");
const { campaignEmail } = require("../_lib/email");

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const pad = (n) => String(n).padStart(2, "0");

async function audience(listId, aud) {
  const all = (await brevo.listContacts(listId)).filter((c) => !c.baja && c.email);
  if (aud === "all" || aud == null || aud === "") return { label: "Todas", list: all };
  const f = FRENOS[Number(aud)];
  if (!f) throw Object.assign(new Error("Audiencia inválida"), { status: 400 });
  return { label: f.name, list: all.filter((c) => c.freno === f.name) };
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Método no permitido" });
  if (!requireAuth(req, res)) return;
  const b = typeof req.body === "string" ? safe(req.body) : req.body || {};
  const mode = b.mode;
  try {
    const listId = await brevo.getListId();

    if (mode === "count") {
      const a = await audience(listId, b.audience);
      return res.status(200).json({ ok: true, count: a.list.length, label: a.label });
    }

    const subject = String(b.subject || "").trim().slice(0, 150);
    const text = String(b.body || "").trim();
    if (!subject || !text) return res.status(400).json({ ok: false, error: "Escribe el asunto y el mensaje." });
    if (b.btnUrl && !/^https?:\/\//i.test(b.btnUrl)) return res.status(400).json({ ok: false, error: "El enlace del botón debe empezar por https://" });
    const opts = { body: text, btnText: b.btnText, btnUrl: b.btnUrl };

    if (mode === "test") {
      const to = String(b.testTo || "").trim().toLowerCase();
      if (!EMAIL_RE.test(to)) return res.status(400).json({ ok: false, error: "Correo de prueba inválido." });
      await brevo.sendEmail({ to, subject: "[PRUEBA] " + subject, html: campaignEmail({ ...opts, test: true }), tags: ["prueba"] });
      return res.status(200).json({ ok: true, sentTo: to });
    }

    if (mode === "send") {
      const a = await audience(listId, b.audience);
      if (!a.list.length) return res.status(400).json({ ok: false, error: "No hay suscriptoras en esa audiencia." });
      const d = new Date();
      const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
      const name = `Envío ${stamp} · ${a.label}`;
      const folders = await brevo.api("GET", "/contacts/folders?limit=1&offset=0");
      const folderId = folders && folders.folders && folders.folders[0] && folders.folders[0].id;
      const tmp = await brevo.api("POST", "/contacts/lists", { name, folderId });
      const emails = a.list.map((c) => c.email);
      for (let i = 0; i < emails.length; i += 150) {
        await brevo.api("POST", `/contacts/lists/${tmp.id}/contacts/add`, { emails: emails.slice(i, i + 150) });
      }
      const s = brevo.sender();
      const camp = await brevo.api("POST", "/emailCampaigns", {
        name, subject, sender: s, htmlContent: campaignEmail(opts), recipients: { listIds: [tmp.id] },
      });
      await brevo.api("POST", `/emailCampaigns/${camp.id}/sendNow`);
      return res.status(200).json({ ok: true, count: emails.length, label: a.label, campaignId: camp.id });
    }

    res.status(400).json({ ok: false, error: "Modo inválido" });
  } catch (e) {
    console.error("[admin/send]", e.message, e.data ? JSON.stringify(e.data) : "");
    res.status(e.status && e.status < 500 ? e.status : 502).json({ ok: false, error: "Brevo respondió: " + (e.data && e.data.message ? e.data.message : e.message) });
  }
};
function safe(s) { try { return JSON.parse(s); } catch (_) { return {}; } }
