const { requireAuth } = require("../_lib/auth");
const brevo = require("../_lib/brevo");
const { FRENOS } = require("../_lib/content");

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    const listId = await brevo.getListId();
    const contacts = await brevo.listContacts(listId);
    const byFreno = {};
    FRENOS.forEach((f) => (byFreno[f.name] = 0));
    let activos = 0;
    contacts.forEach((c) => { if (!c.baja) { activos++; if (c.freno in byFreno) byFreno[c.freno]++; } });
    res.status(200).json({ ok: true, listId, total: contacts.length, activos, byFreno, frenos: FRENOS.map((f) => f.name), contacts });
  } catch (e) {
    console.error("[admin/contacts]", e.message);
    res.status(502).json({ ok: false, error: "No se pudo leer Brevo: " + e.message });
  }
};
