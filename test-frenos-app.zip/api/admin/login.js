const { checkPassword, issueToken } = require("../_lib/auth");
const fails = new Map();

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Método no permitido" });
  if (!process.env.ADMIN_PASSWORD) return res.status(500).json({ ok: false, error: "Falta configurar ADMIN_PASSWORD en Vercel." });
  const ip = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "local";
  const now = Date.now();
  const recent = (fails.get(ip) || []).filter((t) => now - t < 10 * 60000);
  if (recent.length >= 8) return res.status(429).json({ ok: false, error: "Demasiados intentos. Espera unos minutos." });
  const body = typeof req.body === "string" ? safe(req.body) : req.body || {};
  if (!checkPassword(body.password)) {
    recent.push(now); fails.set(ip, recent);
    return res.status(401).json({ ok: false, error: "Contraseña incorrecta." });
  }
  res.status(200).json({ ok: true, ...issueToken(12) });
};
function safe(s) { try { return JSON.parse(s); } catch (_) { return {}; } }
