const { OPTIONS, FRENOS, QUESTIONS } = require("./_lib/content");

// Contenido público del test (mismo que usa el correo).
module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "public, max-age=60, s-maxage=300");
  res.status(200).json({
    options: OPTIONS,
    questions: QUESTIONS.map((q) => ({ t: q.t })),
    frenos: FRENOS,
    cta: process.env.CTA_URL ? { url: process.env.CTA_URL, text: process.env.CTA_TEXT || "" } : null,
  });
};
