const { validAnswers, compute } = require("./_lib/content");

// Calcula el resultado sin guardar nada (se usa al repetir el test).
module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Método no permitido" });
  const body = typeof req.body === "string" ? safeJson(req.body) : req.body || {};
  if (!validAnswers(body.answers)) return res.status(400).json({ ok: false, error: "Respuestas inválidas" });
  res.status(200).json({ ok: true, result: compute(body.answers) });
};

function safeJson(s) { try { return JSON.parse(s); } catch (_) { return {}; } }
